# Model biznesowy wagi interakcji Copilot

## Cel

Model umożliwia porównywanie intensywności użycia Microsoft 365 Copilot między dniami i użytkownikami, gdy źródłowy eksport nie udostępnia rzeczywistej liczby tokenów rozliczeniowych.

## Co mierzymy

Każdy prompt jest łączony z odpowiedzią Copilota. Interakcje bez odpowiedzi są pomijane, ponieważ nie można wiarygodnie ocenić kompletnego przebiegu. Następnie oceniane są:

- długość widocznego tekstu promptu,
- długość widocznego tekstu odpowiedzi,
- obecność zasobu wejściowego,
- obecność rzeczywistego artefaktu wynikowego,
- liczba kontekstów i unikalnych linków źródłowych,
- kontekst aplikacji, w szczególności spotkanie Teams.

Adaptive Card przechowująca sam tekst odpowiedzi nie jest uznawana za wygenerowany plik. Tekst z karty jest wyodrębniany i liczony jako odpowiedź.

## Wagi

| Waga | Nazwa | Zakres ekwiwalentu |
|---:|---|---:|
| 1 | Bardzo lekka | 200-900 |
| 2 | Lekka | 900-3 000 |
| 3 | Zwykła | 3 000-8 000 |
| 4 | Średnia | 8 000-20 000 |
| 5 | Ciężka | 20 000-50 000 |
| 6 | Bardzo ciężka | 50 000-100 000 |

Zakresy są założeniem analitycznym i nie są tokenami naliczonymi przez Microsoft. Należy używać określenia „estymowany ekwiwalent tokenów”.

## Raport biznesowy

Dla każdego dnia raport pokazuje:

- liczbę zapytań w każdej wadze,
- liczbę unikalnych użytkowników,
- sumę środkowego punktu ekwiwalentu tokenów,
- opcjonalny koszt scenariuszowy.

Cena w modelu jest parametrem własnym. Jeżeli zostanie ustawiona na zero, raport nie przedstawia wyceny walutowej.

## Interpretacja

Model służy do rankingu, trendów, segmentacji użytkowników i symulacji PAYG. Nie powinien być używany jako faktura, dowód rzeczywistego zużycia tokenów ani odwzorowanie mechanizmu wewnętrznego Microsoft.
