# Copilot Interaction Cost Model

Pakiet eksportuje historię interakcji Microsoft 365 Copilot, scala prompt z odpowiedzią i przypisuje heurystyczną wagę 1-6.

## Kolejność

1. Skopiuj `config/config.example.psd1` do `config/config.psd1` i uzupełnij wartości.
2. Uruchom PowerShell 7:

```powershell
pwsh ./scripts/Run-All.ps1 -ConfigPath ./config/config.psd1
```

Albo uruchamiaj skrypty osobno w kolejności 01, 02, 03.

## Wyniki

- `data/01-raw`: osobny surowy plik JSON na użytkownika oraz manifest.
- `data/02-merged/merged-interactions.jsonl`: jeden scalony rekord na `requestId`, tylko gdy istnieje `aiResponse`.
- `data/03-scored/interaction-details.csv`: poziom pojedynczych interakcji.
- `data/03-scored/business-summary.csv`: liczba zapytań i unikalnych użytkowników per data i waga.
- `data/03-scored/daily-summary.csv`: dzienne KPI.

## Wymagane uprawnienia aplikacyjne

- `AiEnterpriseInteraction.Read.All`
- uprawnienia pozwalające odczytać członków wskazanej grupy i podstawowe właściwości użytkowników, zgodne z polityką least privilege organizacji.

Wymagany jest admin consent. Certyfikat z kluczem prywatnym musi być dostępny w magazynie `CurrentUser/My` albo `LocalMachine/My` na komputerze uruchamiającym eksport.
