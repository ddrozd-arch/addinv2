# Dokumentacja techniczna

## Źródło danych i autoryzacja

Eksport używa Microsoft Graph `GET /v1.0/copilot/users/{id}/interactionHistory/getAllEnterpriseInteractions`. Token aplikacyjny jest pobierany przez OAuth 2.0 client credentials z podpisanym certyfikatem JWT. Skrypt nie wymaga sekretu klienta ani modułu Microsoft Graph PowerShell.

## Zakres użytkowników

Skrypt pobiera użytkowników ze wskazanej grupy. Domyślnie używa członkostwa tranzytywnego; przełącznik `DirectMembersOnly` ogranicza operację do członków bezpośrednich. Wyłączone konta są pomijane.

## Eksport surowy

Dla każdego użytkownika powstaje oddzielny plik JSON. Obiekty interakcji są zapisywane bez modyfikowania ich pól. Powiązanie pliku z użytkownikiem znajduje się w `_manifest.json`. Obsługiwane są `@odata.nextLink`, throttling 429 oraz przejściowe błędy 5xx.

Zakres dat jest półotwarty: `createdDateTime >= StartDateUtc` i `createdDateTime < EndDateUtc`. Pozwala to uruchamiać kolejne przedziały bez nakładania granic.

## Scalanie

Rekordy są grupowane w obrębie użytkownika według `requestId`. Jest to właściwy klucz pary prompt-odpowiedź. `sessionId` nie jest kluczem scalania, ponieważ sesja może zawierać wiele interakcji.

Reguły:

1. Grupa bez `aiResponse` jest odrzucana.
2. Jeżeli istnieje wiele promptów lub odpowiedzi, wybierany jest rekord najpóźniejszy według `createdDateTime`, a liczności są zachowane w `quality`.
3. Odpowiedź bez promptu jest zachowana i oznaczona `hasPrompt=false`.
4. Wynikiem jest JSON Lines, jeden obiekt na interakcję.

## Ekstrakcja tekstu

- HTML jest dekodowany i usuwany.
- URL-e i znaczniki attachment nie zwiększają liczby tokenów tekstowych.
- Z Adaptive Card pobierane są wartości tekstowe, a powtórzenia są deduplikowane.
- Surowy JSON karty nie jest liczony jako output.
- Estymacja tekstu wykorzystuje `ceil(liczba znaków / 4)`.

Jest to przybliżenie porównawcze, nie tokenizer konkretnego modelu.

## Sygnały zasobów

`PromptHasResource` jest ustawiany dla załącznika innego niż Adaptive Card albo linku typu File/Event/Meeting. `ResponseHasArtifact` oznacza rzeczywisty plik lub obraz wynikowy. Referencja i karta przechowująca tekst nie są automatycznie traktowane jako artefakt.

`ResourceScore` uwzględnia unikalne źródła, contexts, zasób promptu, artefakt odpowiedzi oraz TeamsMeeting. Premia zasobowa wynosi maksymalnie 2 poziomy, co ogranicza zawyżanie wyniku przy wielu metadanych opisujących ten sam zasób.

## Klasa tekstowa i waga końcowa

Klasa tekstowa powstaje z sumy estymowanych tokenów promptu i odpowiedzi:

- do 650: 1,
- do 1 500: 2,
- do 3 500: 3,
- do 8 500: 4,
- do 20 000: 5,
- powyżej 20 000: 6.

`FinalWeight = min(6, TextWeight + min(2, ceil(ResourceScore / 3)))`.

## Czas odpowiedzi

`observedLatencyMs` jest różnicą timestampów promptu i odpowiedzi. Jest przechowywany diagnostycznie, ale nie wpływa na wagę ani tokeny. Endpoint nie dostarcza reasoning tokens ani czasu pracy poszczególnych narzędzi.

## Ograniczenia

- Brak rzeczywistych input, output, cached i reasoning tokens.
- Brak informacji, jaka część dokumentu została użyta przez model.
- Załącznik może być kontenerem UI, źródłem lub artefaktem.
- Zestaw zwracanych interakcji zależy od doświadczeń zapisujących dane do historii.
- Interakcje agentów Copilot Studio nie są objęte tym endpointem.
- Współczynniki trzeba wersjonować i kalibrować względem rzeczywistych kosztów PAYG, jeżeli staną się dostępne.

## Ochrona danych

Pliki zawierają prompty, odpowiedzi i odwołania do zasobów organizacji. Należy stosować kontrolę dostępu, szyfrowanie, retencję, audyt oraz zasady DLP zgodne z wymaganiami organizacji.
