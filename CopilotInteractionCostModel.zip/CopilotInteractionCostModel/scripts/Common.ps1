﻿Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-GraphCertificateToken {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$TenantId,
        [Parameter(Mandatory)][string]$ClientId,
        [Parameter(Mandatory)][string]$CertificateThumbprint
    )
    $thumb = $CertificateThumbprint.Replace(' ','')
    $cert = Get-Item "Cert:\CurrentUser\My\$thumb" -ErrorAction SilentlyContinue
    if (-not $cert) { $cert = Get-Item "Cert:\LocalMachine\My\$thumb" -ErrorAction SilentlyContinue }
    if (-not $cert) { throw "Nie znaleziono certyfikatu $thumb w CurrentUser/My ani LocalMachine/My." }
    if (-not $cert.HasPrivateKey) { throw 'Certyfikat nie ma klucza prywatnego.' }

    $now = [DateTimeOffset]::UtcNow
    $header = @{ alg='RS256'; typ='JWT'; x5t=[Convert]::ToBase64String($cert.GetCertHash()) }
    $payload = @{
        aud = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
        exp = $now.AddMinutes(10).ToUnixTimeSeconds()
        iss = $ClientId
        jti = [guid]::NewGuid().Guid
        nbf = $now.AddMinutes(-1).ToUnixTimeSeconds()
        sub = $ClientId
    }
    function ConvertTo-Base64Url([byte[]]$Bytes) {
        [Convert]::ToBase64String($Bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
    }
    $h = ConvertTo-Base64Url ([Text.Encoding]::UTF8.GetBytes(($header | ConvertTo-Json -Compress)))
    $p = ConvertTo-Base64Url ([Text.Encoding]::UTF8.GetBytes(($payload | ConvertTo-Json -Compress)))
    $unsigned = "$h.$p"
    $rsa = $cert.GetRSAPrivateKey()
    try { $sig = $rsa.SignData([Text.Encoding]::UTF8.GetBytes($unsigned), [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1) }
    finally { if ($rsa) { $rsa.Dispose() } }
    $assertion = "$unsigned.$(ConvertTo-Base64Url $sig)"
    $body = @{
        client_id = $ClientId
        scope = 'https://graph.microsoft.com/.default'
        grant_type = 'client_credentials'
        client_assertion_type = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
        client_assertion = $assertion
    }
    (Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token" -Body $body -ContentType 'application/x-www-form-urlencoded').access_token
}

function Invoke-GraphPagedGet {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Uri,[Parameter(Mandatory)][string]$AccessToken,[int]$MaxRetry=6)
    $next=$Uri
    while($next){
        $attempt=0
        while($true){
            try {
                $r=Invoke-RestMethod -Method Get -Uri $next -Headers @{Authorization="Bearer $AccessToken"} -ContentType 'application/json'
                break
            } catch {
                $status=$_.Exception.Response.StatusCode.value__
                if($attempt -ge $MaxRetry -or $status -notin 429,500,502,503,504){ throw }
                $retryAfter=$_.Exception.Response.Headers['Retry-After']
                $seconds=if($retryAfter){[int]$retryAfter}else{[math]::Min(60,[math]::Pow(2,$attempt))}
                Start-Sleep -Seconds $seconds
                $attempt++
            }
        }
        foreach($item in @($r.value)){ Write-Output $item }
        $next=$r.'@odata.nextLink'
    }
}
