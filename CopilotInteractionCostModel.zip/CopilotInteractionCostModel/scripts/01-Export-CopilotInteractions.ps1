﻿[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$CertificateThumbprint,
    [Parameter(Mandatory)][string]$GroupId,
    [Parameter(Mandatory)][datetime]$StartDateUtc,
    [Parameter(Mandatory)][datetime]$EndDateUtc,
    [string]$OutputPath = '.\data\01-raw',
    [switch]$DirectMembersOnly
)
. "$PSScriptRoot\Common.ps1"
if($EndDateUtc -le $StartDateUtc){ throw 'EndDateUtc musi być późniejsze niż StartDateUtc.' }
New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
$token=Get-GraphCertificateToken -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $CertificateThumbprint
$memberPath=if($DirectMembersOnly){"groups/$GroupId/members/microsoft.graph.user"}else{"groups/$GroupId/transitiveMembers/microsoft.graph.user"}
$membersUri="https://graph.microsoft.com/v1.0/$memberPath`?`$select=id,userPrincipalName,displayName,accountEnabled&`$top=999"
$users=@(Invoke-GraphPagedGet -Uri $membersUri -AccessToken $token | Where-Object {$_.accountEnabled -ne $false})
if(-not $users){ throw 'Grupa nie zwróciła aktywnych użytkowników.' }
$manifest=[ordered]@{
    schemaVersion='1.0'; exportedAtUtc=[datetime]::UtcNow.ToString('o'); tenantId=$TenantId; groupId=$GroupId
    startDateUtc=$StartDateUtc.ToUniversalTime().ToString('o'); endDateUtc=$EndDateUtc.ToUniversalTime().ToString('o')
    users=@(); failures=@()
}
foreach($u in $users){
    try {
        $safe=($u.userPrincipalName -replace '[^a-zA-Z0-9._-]','_')
        $file=Join-Path $OutputPath "$safe.json"
        $from=[uri]::EscapeDataString($StartDateUtc.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ'))
        $to=[uri]::EscapeDataString($EndDateUtc.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ'))
        $filter=[uri]::EscapeDataString("createdDateTime ge $($StartDateUtc.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')) and createdDateTime lt $($EndDateUtc.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ'))")
        $uri="https://graph.microsoft.com/v1.0/copilot/users/$($u.id)/interactionHistory/getAllEnterpriseInteractions?`$top=100&`$filter=$filter"
        $records=@(Invoke-GraphPagedGet -Uri $uri -AccessToken $token)
        # Plik użytkownika zawiera rekordy Graph bez ingerencji w pola rekordu.
        $records | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $file -Encoding utf8
        $manifest.users += [ordered]@{id=$u.id;userPrincipalName=$u.userPrincipalName;displayName=$u.displayName;file=[IO.Path]::GetFileName($file);recordCount=$records.Count}
        Write-Host "[$($u.userPrincipalName)] $($records.Count) rekordów"
    } catch {
        $manifest.failures += [ordered]@{id=$u.id;userPrincipalName=$u.userPrincipalName;error=$_.Exception.Message}
        Write-Warning "[$($u.userPrincipalName)] $($_.Exception.Message)"
    }
}
$manifest | ConvertTo-Json -Depth 20 | Set-Content (Join-Path $OutputPath '_manifest.json') -Encoding utf8
if($manifest.failures.Count -gt 0){ Write-Warning "Eksport zakończony z błędami: $($manifest.failures.Count)." }
