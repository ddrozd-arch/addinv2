﻿[CmdletBinding()]
param(
 [string]$InputPath='.\data\02-merged\merged-interactions.jsonl',
 [string]$OutputDirectory='.\data\03-scored',
 [string]$MultiplierPath=(Join-Path $PSScriptRoot '..\reference\weight-multipliers.csv'),
 [double]$CurrencyPer1KEquivalentTokens=0
)
Set-StrictMode -Version Latest;$ErrorActionPreference='Stop'
New-Item -ItemType Directory -Path $OutputDirectory -Force|Out-Null
$multipliers=Import-Csv $MultiplierPath
function Strip-Markup([string]$s){if([string]::IsNullOrWhiteSpace($s)){return ''};$x=[Net.WebUtility]::HtmlDecode($s);$x=[regex]::Replace($x,'<attachment\b[^>]*>.*?</attachment>',' ','IgnoreCase,Singleline');$x=[regex]::Replace($x,'<[^>]+>',' ');$x=[regex]::Replace($x,'https?://\S+',' ');[regex]::Replace($x,'\s+',' ').Trim()}
function Get-CardText($node){
 $parts=[Collections.Generic.List[string]]::new()
 function Walk($n){
   if($null-eq $n){return}
   if($n -is [string]){return}
   if($n -is [Collections.IEnumerable] -and $n -isnot [pscustomobject]){foreach($i in $n){Walk $i};return}
   foreach($p in $n.PSObject.Properties){
      if($p.Name -in 'text','title','value' -and $p.Value -is [string]){$t=Strip-Markup $p.Value;if($t){$parts.Add($t)}}
      elseif($p.Value -isnot [string]){Walk $p.Value}
   }
 }
 Walk $node
 ($parts|Select-Object -Unique)-join "`n"
}
function Get-VisibleText($record){
 if(-not $record){return ''}
 $parts=[Collections.Generic.List[string]]::new();$body=Strip-Markup $record.body.content;if($body){$parts.Add($body)}
 foreach($a in @($record.attachments)){
   if($a.contentType -eq 'application/vnd.microsoft.card.adaptive' -and $a.content){try{$parts.Add((Get-CardText ($a.content|ConvertFrom-Json)))}catch{}}
   elseif($a.content -and ($a.contentType -match '^text/')){$parts.Add((Strip-Markup $a.content))}
 }
 (($parts|Where-Object {$_}|Select-Object -Unique)-join "`n").Trim()
}
function Has-InputResource($record){
 foreach($a in @($record.attachments)){if($a.contentType -ne 'application/vnd.microsoft.card.adaptive'){return $true}}
 foreach($l in @($record.links)){if($l.linkType -in 'File','Event','Meeting'){return $true}}
 return $false
}
function Has-OutputArtifact($record){foreach($a in @($record.attachments)){if($a.contentType -match '^(file|image/)' -or ($a.contentType -notin 'application/vnd.microsoft.card.adaptive','reference' -and $a.name)){return $true}};return $false}
function App-Group($r){
 $s=((@($r.contexts|ForEach-Object contextType)+@($r.from.application.displayName)+@($r.appClass)+@($r.conversationType))-join ' ')
 if($s-match 'TeamsMeeting|Meeting'){return 'TeamsMeeting'};if($s-match 'Excel'){return 'Excel'};if($s-match 'PowerPoint'){return 'PowerPoint'};if($s-match 'Word'){return 'Word'};if($s-match 'Loop'){return 'Loop'};if($s-match 'Outlook'){return 'Outlook'};if($s-match 'Teams'){return 'Teams'};if($s-match 'BizChat|Microsoft 365 Chat|bizchat'){return 'BizChat'};'Unknown'
}
$details=[Collections.Generic.List[object]]::new()
Get-Content $InputPath | ForEach-Object {
 if(-not $_){return};$x=$_|ConvertFrom-Json
 $pt=Get-VisibleText $x.prompt;$rt=Get-VisibleText $x.response
 $pTok=[math]::Ceiling($pt.Length/4.0);$rTok=[math]::Ceiling($rt.Length/4.0);$obs=$pTok+$rTok
 $textWeight=if($obs-le 650){1}elseif($obs-le 1500){2}elseif($obs-le 3500){3}elseif($obs-le 8500){4}elseif($obs-le 20000){5}else{6}
 $promptResource=Has-InputResource $x.prompt;$outputArtifact=Has-OutputArtifact $x.response
 $contexts=@($x.response.contexts).Count;$sourceLinks=@($x.response.links|Where-Object {$_.linkType -in 'File','Event','Meeting'}|ForEach-Object linkUrl|Select-Object -Unique).Count
 $resourceScore=0;if($sourceLinks-eq 1){$resourceScore+=1}elseif($sourceLinks-gt 1){$resourceScore+=2};if($contexts-eq 1){$resourceScore+=1}elseif($contexts-gt 1){$resourceScore+=2};if($promptResource){$resourceScore+=2};if($outputArtifact){$resourceScore+=2};if((App-Group $x.response)-eq 'TeamsMeeting'){$resourceScore+=2}
 $bonus=[math]::Min(2,[math]::Ceiling($resourceScore/3.0));$weight=[math]::Min(6,$textWeight+$bonus)
 $m=$multipliers|Where-Object {[int]$_.Weight-eq $weight}|Select-Object -First 1
 $cost=if($CurrencyPer1KEquivalentTokens-gt 0){([double]$m.MidEquivalentTokens/1000)*$CurrencyPer1KEquivalentTokens}else{0}
 $details.Add([pscustomobject]@{Date=([datetime]$x.interactionDateUtc).ToString('yyyy-MM-dd');UserPrincipalName=$x.userPrincipalName;RequestId=$x.requestId;Application=(App-Group $x.response);PromptTokensEstimated=$pTok;ResponseTokensEstimated=$rTok;ObservableTokens=$obs;PromptHasResource=$promptResource;ResponseHasArtifact=$outputArtifact;ContextCount=$contexts;SourceLinkCount=$sourceLinks;ResourceScore=$resourceScore;Weight=$weight;WeightLabel=$m.Label;EquivalentTokensMin=$m.MinEquivalentTokens;EquivalentTokensMid=$m.MidEquivalentTokens;EquivalentTokensMax=$m.MaxEquivalentTokens;EstimatedCost=[math]::Round($cost,6);ObservedLatencyMs=$x.observedLatencyMs})
}
$details|Export-Csv (Join-Path $OutputDirectory 'interaction-details.csv') -NoTypeInformation -Encoding utf8
$summary=$details|Group-Object Date,Weight|ForEach-Object{
 $rows=$_.Group;[pscustomobject]@{Date=$rows[0].Date;Weight=$rows[0].Weight;WeightLabel=$rows[0].WeightLabel;QueryCount=$rows.Count;UniqueUsers=@($rows.UserPrincipalName|Sort-Object -Unique).Count;EquivalentTokensMid=[double](($rows|Measure-Object EquivalentTokensMid -Sum).Sum);EstimatedCost=[double](($rows|Measure-Object EstimatedCost -Sum).Sum)}
}|Sort-Object Date,Weight
$summary|Export-Csv (Join-Path $OutputDirectory 'business-summary.csv') -NoTypeInformation -Encoding utf8
$daily=$details|Group-Object Date|ForEach-Object{$r=$_.Group;[pscustomobject]@{Date=$_.Name;QueryCount=$r.Count;UniqueUsers=@($r.UserPrincipalName|Sort-Object -Unique).Count;AverageWeight=[math]::Round((($r|Measure-Object Weight -Average).Average),2);EquivalentTokensMid=[double](($r|Measure-Object EquivalentTokensMid -Sum).Sum);EstimatedCost=[double](($r|Measure-Object EstimatedCost -Sum).Sum)}}|Sort-Object Date
$daily|Export-Csv (Join-Path $OutputDirectory 'daily-summary.csv') -NoTypeInformation -Encoding utf8
Write-Host "Oceniono $($details.Count) interakcji. Wynik: $OutputDirectory"
