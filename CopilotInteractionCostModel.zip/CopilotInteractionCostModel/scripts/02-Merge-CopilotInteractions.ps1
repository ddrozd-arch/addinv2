﻿[CmdletBinding()]
param([string]$InputPath='.\data\01-raw',[string]$OutputPath='.\data\02-merged\merged-interactions.jsonl')
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$manifestPath=Join-Path $InputPath '_manifest.json'
if(-not (Test-Path $manifestPath)){throw "Brak $manifestPath"}
$manifest=Get-Content $manifestPath -Raw | ConvertFrom-Json
New-Item -ItemType Directory -Path (Split-Path $OutputPath) -Force | Out-Null
$writer=[IO.StreamWriter]::new((Resolve-Path (Split-Path $OutputPath)).Path+'\'+(Split-Path $OutputPath -Leaf),$false,[Text.UTF8Encoding]::new($false))
$stats=[ordered]@{inputRecords=0;outputInteractions=0;discardedWithoutResponse=0;responseOnly=0}
try {
 foreach($user in $manifest.users){
    $path=Join-Path $InputPath $user.file
    $records=if(Test-Path $path){@(Get-Content $path -Raw | ConvertFrom-Json)}else{@()}
    $stats.inputRecords += $records.Count
    foreach($g in ($records | Where-Object {$_.requestId} | Group-Object requestId)){
        $responses=@($g.Group | Where-Object interactionType -eq 'aiResponse' | Sort-Object createdDateTime)
        if(-not $responses){$stats.discardedWithoutResponse += $g.Count;continue}
        $prompts=@($g.Group | Where-Object interactionType -eq 'userPrompt' | Sort-Object createdDateTime)
        if(-not $prompts){$stats.responseOnly++}
        $prompt=if($prompts){$prompts[-1]}else{$null}
        $response=$responses[-1]
        $obj=[ordered]@{
            schemaVersion='1.0';userId=$user.id;userPrincipalName=$user.userPrincipalName;displayName=$user.displayName
            requestId=$g.Name;sessionId=$response.sessionId
            interactionDateUtc=([datetime]$response.createdDateTime).ToUniversalTime().ToString('o')
            observedLatencyMs=if($prompt){[math]::Max(0,([datetime]$response.createdDateTime-[datetime]$prompt.createdDateTime).TotalMilliseconds)}else{$null}
            prompt=$prompt;response=$response
            quality=[ordered]@{hasPrompt=[bool]$prompt;promptRecordCount=$prompts.Count;responseRecordCount=$responses.Count}
        }
        $writer.WriteLine(($obj|ConvertTo-Json -Depth 100 -Compress));$stats.outputInteractions++
    }
 }
} finally {$writer.Dispose()}
$stats|ConvertTo-Json|Set-Content ((Split-Path $OutputPath)+ '\merge-stats.json') -Encoding utf8
Write-Host "Utworzono $($stats.outputInteractions) scalonych interakcji."
