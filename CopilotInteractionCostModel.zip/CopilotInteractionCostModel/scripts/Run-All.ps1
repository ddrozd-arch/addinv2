﻿[CmdletBinding()]
param([Parameter(Mandatory)][string]$ConfigPath)
$config=Import-PowerShellDataFile $ConfigPath
$exportParams=@{
 TenantId=$config.TenantId; ClientId=$config.ClientId; CertificateThumbprint=$config.CertificateThumbprint
 GroupId=$config.GroupId; StartDateUtc=$config.StartDateUtc; EndDateUtc=$config.EndDateUtc; OutputPath=$config.OutputPath
}
if($config.DirectMembersOnly){$exportParams.DirectMembersOnly=$true}
& "$PSScriptRoot\01-Export-CopilotInteractions.ps1" @exportParams
if(-not $?){exit 1}
& "$PSScriptRoot\02-Merge-CopilotInteractions.ps1" -InputPath $config.OutputPath
if(-not $?){exit 1}
& "$PSScriptRoot\03-Score-CopilotInteractions.ps1" -CurrencyPer1KEquivalentTokens $config.CurrencyPer1KEquivalentTokens
