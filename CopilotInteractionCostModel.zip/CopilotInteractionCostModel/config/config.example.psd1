﻿@{
 TenantId='00000000-0000-0000-0000-000000000000'
 ClientId='00000000-0000-0000-0000-000000000000'
 CertificateThumbprint='CERTIFICATE_THUMBPRINT'
 GroupId='00000000-0000-0000-0000-000000000000'
 StartDateUtc=[datetime]'2026-09-01T00:00:00Z'
 EndDateUtc=[datetime]'2026-10-01T00:00:00Z'
 OutputPath='.\data\01-raw'
 DirectMembersOnly=$false
 # Własny scenariusz kosztowy. 0 oznacza brak wyceny walutowej.
 CurrencyPer1KEquivalentTokens=0
}
